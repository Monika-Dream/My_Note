# Java 笔记

- ### 1.在 Java 中 <span data-type="text" style="color: var(--b3-font-color7);">类名</span> 要和 <span data-type="text" style="color: var(--b3-font-color7);">文件名</span> 完全<span data-type="text" style="color: var(--b3-font-color7);">一致</span>

# Java 类库记录

```java
// java 帮我们写好了一个类叫 Scanner ，这个类可以接收键盘输入的数字
import  java.util.Scanner
// Scanner  应该是类型的定义
Scanner sc = new Scanner( System.in )
int i = sc.nextInt()
```

‍
